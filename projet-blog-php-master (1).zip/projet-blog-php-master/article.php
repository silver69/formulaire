<?php
    $filename = './data/data.json';
    $_POST = filter_input_array(INPUT_POST, [
        'id' => FILTER_VALIDATE_INT,
        'action' => FILTER_SANITIZE_FULL_SPECIAL_CHARS
    ]);

    if ($_SERVER["REQUEST_METHOD"] === "POST") {
        $id = $_POST['id'] ?? '';
        $action = $_POST['action'] ?? '';

        if ($id && $action) {
            $articles = json_decode(file_get_contents($filename), true) ?? [];
            if (count($articles)) {
                $articleIndex = array_search($id, array_column($articles, 'id'));
                if ($action === 'detail' || $action === 'edit') { 
                    $title = $articles[$articleIndex]['title'];
                    $category = $articles[$articleIndex]['category'];
                    $image = $articles[$articleIndex]['image'];
                    $description = $articles[$articleIndex]['description'];
                }
                if ($action === 'remove'){ 
                    array_splice($articles, $articleIndex, 1);
                    header('Location: /index.php');
                }
                file_put_contents($filename, json_encode($articles));
            }
        }
    }
?>

<!DOCTYPE html>
<html lang="fr">

<head>
    <?php require_once './includes/head.php' ?>
</head>

<body>
    <div class="container">
        <?php require_once './includes/header.php' ?>
        <div class="content contentArticle">
            <div>
               <img src="<?= $image ?>" alt="<?= $title ?>"> 
            </div>           
            <div>
                <?= "Titre : " . $title ?>
            </div>
            <div>
                <?= "Catégorie : " . ucfirst($category) ?>
            </div>
            <div>
                <?= "Description : " .$description ?>
            </div> 
            <form action="/modify-article.php" method="POST" class="m-0">
                <input type="hidden" name="id" value="<?= $articles[$articleIndex]['id'] ?>">
                <input type="hidden" name="action" value="modify">
                <button type="submit" class="btn btn-primary btn-small">Modifier</button>
            </form>
            
            <form action="/article.php" method="POST" class="m-0">
                <input type="hidden" name="id" value="<?= $articles[$articleIndex]['id'] ?>">
                <input type="hidden" name="action" value="remove">
                <button type="submit" class="btn btn-danger btn-small">Supprimer</button>
            </form>                  
        </div>
        <?php require_once './includes/footer.php' ?>
    </div>
</body>

</html>