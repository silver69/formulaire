<?php
const ERROR_REQUIRED = 'Veuillez renseigner une information';
const ERROR_TOO_SHORT = 'Veuillez entrer au moins 4 caractères';
const ERROR_TOO_LONG = 'Veuillez entrer au maximum 200 caractères';