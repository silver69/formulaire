<?php
    $filename = "./data/data.json";
    $jsonData = array();
    include_once 'errors.php';

    if (file_exists($filename)) {
        $jsonData = json_decode(file_get_contents($filename));
    }   
    
    $errors = [
        'title' => '',
        'image' => '',
        'description' => '',
        'category' => ''
    ];

    if ($_SERVER["REQUEST_METHOD"] === "POST") {
        // Filtre pour sécuriser les input du formulaire
        $_POST = filter_input_array(INPUT_POST, [
            'title' => [
                'filter' => FILTER_SANITIZE_FULL_SPECIAL_CHARS,
                'flags' => FILTER_FLAG_NO_ENCODE_QUOTES | FILTER_FLAG_STRIP_BACKTICK
            ],
            'image'  => [
                'filter' => FILTER_SANITIZE_FULL_SPECIAL_CHARS,
                'flags' => FILTER_FLAG_NO_ENCODE_QUOTES | FILTER_FLAG_STRIP_BACKTICK
            ],
            'description'  => [
                'filter' => FILTER_SANITIZE_FULL_SPECIAL_CHARS,
                'flags' => FILTER_FLAG_NO_ENCODE_QUOTES | FILTER_FLAG_STRIP_BACKTICK
            ],
            'category'  => [
                'filter' => FILTER_SANITIZE_FULL_SPECIAL_CHARS,
                'flags' => FILTER_FLAG_NO_ENCODE_QUOTES | FILTER_FLAG_STRIP_BACKTICK
            ],
        ]);
    
            // Récupération de la valeur et stocker dans une variable
        $formData = $_POST ; 
        
        //Condition pour la gestion des erreurs
        if ($formData) {
            //Titre    
            if (!$formData['title']) {
                $errors['title'] = ERROR_REQUIRED;
            } elseif (strlen($formData['title']) < 4) {
                $errors['title'] = ERROR_TOO_SHORT;
            } elseif (strlen($formData['title']) > 200) {
                $errors['title'] = ERROR_TOO_LONG;
            }
        
            //Image    
            if (!$formData['image']) {
                $errors['image'] = ERROR_REQUIRED;
            } elseif (strlen($formData['image']) < 4) {
                $errors['image'] = ERROR_TOO_SHORT;
            } elseif (strlen($formData['image']) > 200) {
                $errors['image'] = ERROR_TOO_LONG;
            }
        
            //Description
            if (!$formData['description']) {
                $errors['description'] = ERROR_REQUIRED;
            } elseif (strlen($formData['description']) < 4) {
                $errors['description'] = ERROR_TOO_SHORT;
            } elseif (strlen($formData['description']) > 200) {
                $errors['description'] = ERROR_TOO_LONG;
            } 
        } 
        
        if (empty(array_filter($errors, fn ($e) => $e !== ''))) {
            $dataToFile = array(
                'id' => time(),
                "title" => $formData['title'],
                "image" => $formData['image'],
                "description" => $formData['description'],
                "category" => $formData['category']
            );
            array_push($jsonData , $dataToFile);
            file_put_contents($filename, json_encode($jsonData));
            header('Location: /index.php');
        }    
    }    
?>


<!DOCTYPE html>
<html lang="fr">

<head>
    <?php require_once './includes/head.php' ?>
</head>

<body>
    <div class="container">
        <?php require_once './includes/header.php' ?>
        <div class="content"> 
            <div class="block p-20 form-container">
                <h1>Écrire un article</h1>
                <form action="./add-article.php" method="post">
                    <div class="form-control">
                        <label for="title">Titre :</label>
                        <input type="text" name="title" value="<?php if(isset($_POST['title'])) { echo $_POST['title']; }?>">
                    </div>
                    <div class="form-control">
                        <label for="image">Image :</label>
                        <input type="text" name="image" value="<?php if(isset($_POST['nom'])) { echo $_POST['nom']; }?>">
                    </div>
                    <div class="form-control">
                        <label for="description">Description :</label>
                        <textarea name="description"><?php if(isset($_POST['description'])) { echo $_POST['description']; }?></textarea>
                    </div>
                    <div class="form-control">
                        <label for="category">Categorie :</label>
                        <select name="category">
                            <option value="" disabled selected>Choisissez une valeur</option>
                            <option value="nature" <?php echo (isset($_POST['category']) && $_POST['category'] === 'nature') ? 'selected' : ''; ?>>Nature</option>
                            <option value="technology" <?php echo (isset($_POST['category']) && $_POST['category'] === 'technology') ? 'selected' : ''; ?>>Technologie</option>
                            <option value="politics" <?php echo (isset($_POST['category']) && $_POST['category'] === 'politics') ? 'selected' : ''; ?>>Politique</option>
                        </select>
                    </div>
                    <div class="form-action">
                        <button type="submit" class="btn btn-submit">Sauvegarde</button>
                        <a href="./index.php">
                            <button class="btn btn-danger">Annuler</button>
                        </a>
                    </div>
                </form>
            </div>
        </div>
        <?php require_once './includes/footer.php' ?>
    </div>
</body>

</html>