<?php
     $filename = "./data/data.json";
     $jsonData = array();
     include_once 'errors.php';
 
     if (file_exists($filename)) {
         $articles = json_decode(file_get_contents($filename));
     }   
     
     $errors = [
         'title' => '',
         'image' => '',
         'description' => '',
         'category' => ''
     ];
 
    // Filtre pour sécuriser les input du formulaire
    $_POST = filter_input_array(INPUT_POST, [
        'id' => FILTER_VALIDATE_INT,
        'action' => FILTER_SANITIZE_FULL_SPECIAL_CHARS,
        'title' => [
            'filter' => FILTER_SANITIZE_FULL_SPECIAL_CHARS,
            'flags' => FILTER_FLAG_NO_ENCODE_QUOTES | FILTER_FLAG_STRIP_BACKTICK
        ],
        'image'  => [
            'filter' => FILTER_SANITIZE_FULL_SPECIAL_CHARS,
            'flags' => FILTER_FLAG_NO_ENCODE_QUOTES | FILTER_FLAG_STRIP_BACKTICK
        ],
        'description'  => [
            'filter' => FILTER_SANITIZE_FULL_SPECIAL_CHARS,
            'flags' => FILTER_FLAG_NO_ENCODE_QUOTES | FILTER_FLAG_STRIP_BACKTICK
        ],
        'category'  => [
            'filter' => FILTER_SANITIZE_FULL_SPECIAL_CHARS,
            'flags' => FILTER_FLAG_NO_ENCODE_QUOTES | FILTER_FLAG_STRIP_BACKTICK
        ],
    ]);
     
    // Récupération de la valeur et stocker dans une variable
     $formData = $_POST ; 
     $id = $_POST['id'] ?? '';
     $action = $_POST['action'] ?? '';
     
     //Condition pour la gestion des erreurs
     if ($formData) {
         //Titre    
         if (!$formData['title']) {
             $errors['title'] = ERROR_REQUIRED;
         } elseif (strlen($formData['title']) < 4) {
             $errors['title'] = ERROR_TOO_SHORT;
         } elseif (strlen($formData['title']) > 200) {
             $errors['title'] = ERROR_TOO_LONG;
         }
     
         //Image    
         if (!$formData['image']) {
             $errors['image'] = ERROR_REQUIRED;
         } elseif (strlen($formData['image']) < 4) {
             $errors['image'] = ERROR_TOO_SHORT;
         } elseif (strlen($formData['image']) > 200) {
             $errors['image'] = ERROR_TOO_LONG;
         }
     
         //Description
         if (!$formData['description']) {
             $errors['description'] = ERROR_REQUIRED;
         } elseif (strlen($formData['description']) < 4) {
             $errors['description'] = ERROR_TOO_SHORT;
         } elseif (strlen($formData['description']) > 200) {
             $errors['description'] = ERROR_TOO_LONG;
         } 
     } 
     
     if (empty(array_filter($errors, fn ($e) => $e !== ''))) {
         $modifyFile = array(
             "id" => $id,
             "title" => $formData['title'],
             "image" => $formData['image'],
             "description" => $formData['description'],
             "category" => $formData['category']
         );
         array_push($jsonData , $dataToFile);         
     }      
     
    if ($id && $action) {
        $articles = json_decode(file_get_contents($filename), true) ?? [];
        if (count($articles)) {
            $articleIndex = array_search($id, array_column($articles, 'id'));
            if ($action === 'modify') { 
                $title = $articles[$articleIndex]['title'];
                $category = $articles[$articleIndex]['category'];
                $image = $articles[$articleIndex]['image'];
                $description = $articles[$articleIndex]['description'];
            }
            if ($action === 'edit'){ 
                $articles[$articleIndex]['title'] = $modifyFile['title'];
                $articles[$articleIndex]['category'] = $modifyFile['category'];
                $articles[$articleIndex]['image'] = $modifyFile['image'];
                $articles[$articleIndex]['description'] = $modifyFile['description'];
                header('Location: /article.php');
            }
            file_put_contents($filename, json_encode($articles));
        }
    }
   
?>

<!DOCTYPE html>
<html lang="fr">

<head>
    <?php require_once './includes/head.php' ?>
    <link rel="stylesheet" href="./assets/css/add-article.css">
</head>

<body>
    <div class="container">
        <?php require_once './includes/header.php' ?>
        <div class="content"> 
            <div class="block p-20 form-container">
                <h1>Écrire un article</h1>
                <form action="./modify-article.php" method="post">
                    <div class="form-control">
                        <label for="title">Titre :</label>
                        <input type="text" name="title" value="<?php 
                            echo $title;
                            if(isset($_POST['title'])) { $title=$_POST['title']; }
                        ?>">
                    </div>
                    <div class="form-control">
                        <label for="image">Image :</label>
                        <input type="text" name="image" value="<?php 
                            echo $image;
                            if(isset($_POST['image'])) { $image=$_POST['image']; }
                        ?>">
                    </div>
                    <div class="form-control">
                        <label for="description">Description :</label>
                        <textarea name="description">
                            <?php 
                                echo $description;
                                if(isset($_POST['description'])) { $description=$_POST['description']; }
                            ?>
                        </textarea>
                    </div>
                    <div class="form-control">
                        <label for="category">Categorie :</label>
                        <select name="category">
                            <option value="" disabled selected>Choisissez une valeur</option>
                            <option value="nature" <?php echo (isset($_POST['category']) && $_POST['category'] === 'nature' || strtolower($category) === 'nature') ? 'selected' : ''; ?>>Nature</option>
                            <option value="technology" <?php echo (isset($_POST['category']) && $_POST['category'] === 'technology' || strtolower($category) === 'technology') ? 'selected' : ''; ?>>Technologie</option>
                            <option value="politics" <?php echo (isset($_POST['category']) && $_POST['category'] === 'politics' || strtolower($category) === 'politics') ? 'selected' : ''; ?>>Politique</option>
                        </select>
                    </div>
                    <div class="form-action">
                    <form action="/modify-article.php" method="POST" class="m-0">
                        <input type="hidden" name="id" value="<?= $id ?>">
                        <input type="hidden" name="action" value="edit">
                        <button type="submit" class="btn btn-primary btn-small">Modifier</button>
                    </form>
                        
                        <a href="./article.php">
                            <button class="btn btn-danger">Annuler</button>
                        </a>
                    </div>
                </form>
            </div>
        </div>
        <?php require_once './includes/footer.php' ?>
    </div>
</body>

</html>