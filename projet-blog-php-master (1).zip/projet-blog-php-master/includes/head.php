<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<!-- Changer titre de la page en fonction du nom du fichier -->
<?php // extract the filename
 $filename = basename($_SERVER['SCRIPT_FILENAME'], '.php');
 // replace dashes with whitespace
 $filename = str_replace('_', ' ', $filename);
 // check if the file is index, if so assign 'home' to the title instead of index
 if (strtolower($filename) == 'index') {
    $title = 'Blog';
 }
 elseif (strtolower($filename) == 'add-article'){
    $title = 'Créer un article';
 }

 
 ?>

 <title><?= $title ?></title>
 <link rel="stylesheet" href="./assets/css/style.css">
 <link rel="stylesheet" href="./assets/css/<?= $filename ?>.css">