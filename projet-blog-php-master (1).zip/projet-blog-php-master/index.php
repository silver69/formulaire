<?php
    // Variable qui stocke le chemin du fichier JSON
    $filename = "./data/data.json";
        
    $articles = array();

    if (file_exists($filename)) {
        $articles = json_decode(file_get_contents($filename));
    }
   
?>

<!DOCTYPE html>
<html lang="fr">

<head>
    <?php require_once './includes/head.php' ?>
</head>

<body>
    <div class="container">
        <?php require_once './includes/header.php' ?>
        <div class="content">
        <?php if($articles){ ?>
                <?php foreach ($articles as $article) { ?>
                    <div class="article">               
                        <div class="imageArticle">
                            <img src="<?=$article->image?>" alt="<?=$article->title?>">
                        </div>
                        <div class="infoArticle">
                            <span>
                                <?= $article->title?>                                
                            </span>
                            <form action="./article.php" method="POST" class="m-0">  
                                <input type="hidden" name="id" value="<?= $article->id ?>">
                                <input type="hidden" name="action" value="detail">
                                <button type="submit" class="btn btn-primary">Détail</button>
                            </form>                                
                        </div>                        
                    </div>
                <?php } ?>
            <?php } ?>
        </div>
        <?php require_once './includes/footer.php' ?>
    </div>
</body>

</html>